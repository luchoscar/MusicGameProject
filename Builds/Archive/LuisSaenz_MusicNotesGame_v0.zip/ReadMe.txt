Collect all objects emitting partiles
Look for the translucent blocks to get a speed boost
Try to keep the music playing after collecting a particle emitter
Game controllers:
  -W: Accelerate
  -S: Desaccelerate
  -A: Rotate left
  -D: Rotate right
  -Space bar